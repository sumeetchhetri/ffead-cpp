
# to use module `sqlite`, install `sqlite-devel` first.

for **Fedora 31**:

     sudo dnf -y install `sqlite-devel`


 for **Ubuntu 20.04**:
     sudo apt install -y `libsqlite3-dev`
     


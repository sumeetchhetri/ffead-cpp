#include "header.h"

int cadd(int a, int b) {
    return a + b;
}

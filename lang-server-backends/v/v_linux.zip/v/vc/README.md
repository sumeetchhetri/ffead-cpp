# vc
V compiler's source translated to C.

This repository is generated automatically. Please do not submit PRs here, use the main repo:

[github.com/vlang/v](https://github.com/vlang/v)


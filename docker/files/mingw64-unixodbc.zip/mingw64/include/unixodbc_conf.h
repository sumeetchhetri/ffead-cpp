/* unixodbc_conf.h.  Generated from unixodbc_conf.h.in by configure.  */
#ifndef HAVE_UNISTD_H
#define HAVE_UNISTD_H 1
#endif

#ifndef HAVE_PWD_H
/* #undef HAVE_PWD_H */
#endif

#ifndef HAVE_SYS_TIME_H
#define HAVE_SYS_TIME_H 1
#endif

#ifndef ODBC_STD
/* #undef ODBC_STD */
#endif

#ifndef UNICODE
/* #undef UNICODE */
#endif

#ifndef GUID_DEFINED
/* #undef GUID_DEFINED */
#endif

#ifndef SQL_WCHART_CONVERT
/* #undef SQL_WCHART_CONVERT */
#endif

#ifndef HAVE_LONG_LONG
#define HAVE_LONG_LONG 1
#endif

#ifndef ODBCINT64_TYPEA
/* #undef ODBCINT64_TYPEA */
#endif

#ifndef UODBCINT64_TYPE
/* #undef UODBCINT64_TYPE */
#endif

#ifndef DISABLE_INI_CACHING
/* #undef DISABLE_INI_CACHING */
#endif

#ifndef SIZEOF_LONG_INT
#define SIZEOF_LONG_INT 4
#endif

#ifndef ALLREADY_HAVE_WINDOWS_TYPE
/* #undef ALLREADY_HAVE_WINDOWS_TYPE */
#endif

#ifndef DONT_TD_VOID
/* #undef DONT_TD_VOID */
#endif

#ifndef DO_YOU_KNOW_WHAT_YOUR_ARE_DOING
/* #undef DO_YOU_KNOW_WHAT_YOUR_ARE_DOING */
#endif
